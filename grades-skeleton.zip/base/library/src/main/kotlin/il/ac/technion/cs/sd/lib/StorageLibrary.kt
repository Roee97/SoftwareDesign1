package il.ac.technion.cs.sd.lib

import il.ac.technion.cs.sd.grades.external.LineStorage

/**
 * Implement your library here. Feel free to change the class name,
 * but note that if you choose to change the class name,
 * you will need to update the import statements in GradesInitializer.kt
 * and in GradesReader.kt.
 */
class StorageLibrary {
    /** TODO: Implement me! */
}