package il.ac.technion.cs.sd.lib

import org.junit.jupiter.api.*

/** Use this class to test your library implementation */
class StorageLibraryTest {

}