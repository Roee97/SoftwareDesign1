plugins {
    id("buildlogic.kotlin-application-conventions")
}

dependencies {
    api(project(":library"))
}