plugins {
    id("buildlogic.kotlin-common-conventions")
    `java-library`
}