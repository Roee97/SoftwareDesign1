plugins {
    id("buildlogic.kotlin-common-conventions")
    application
}