plugins {
    id("buildlogic.kotlin-common-conventions")
}

dependencies {
    implementation(project(":grades-app"))
}